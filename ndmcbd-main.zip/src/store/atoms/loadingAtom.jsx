import { atom } from "recoil";

export const eventLoading = atom({
  key: "eventLoading",
  default: true,
});
