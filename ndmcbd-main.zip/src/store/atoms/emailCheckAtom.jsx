import { atom } from "recoil";

export const emailStatus = atom({
  key: "eventFormEmailStatus",
  default: "",
});
