import { atom } from "recoil";

export const generalLoading = atom({
  key: "generalLoading",
  default: false,
});
