import { atom } from "recoil";

export const festStatus = atom({
  key: "festStatus",
  default: {},
});
