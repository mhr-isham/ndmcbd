export const url = import.meta.env.VITE_URL;
