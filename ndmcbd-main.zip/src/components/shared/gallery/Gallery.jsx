import styled from "@emotion/styled";

export const GalleryImage = styled.div`
  & :hover {
    scale: 1.1;
  }
`;
